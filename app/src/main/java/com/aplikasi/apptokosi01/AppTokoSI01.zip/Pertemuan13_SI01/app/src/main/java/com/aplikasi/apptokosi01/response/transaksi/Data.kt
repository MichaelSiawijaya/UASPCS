package com.aplikasi.apptokosi01.response.transaksi

data class Data(
    val transaksi: List<Transaksi>,
    val total:String
)