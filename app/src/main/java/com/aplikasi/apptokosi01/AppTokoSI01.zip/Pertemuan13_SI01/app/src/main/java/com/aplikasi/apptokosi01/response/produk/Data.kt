package com.aplikasi.apptokosi01.response.produk

data class Data(
    val produk: List<Produk>
)
